import type { CjRawProduct, CjRawProductDetail, CjRawReview } from "./types";

const CJ_BASE = "https://developers.cjdropshipping.com/api2.0/v1";

// --- Gestion du token -------------------------------------------------
// Le token dure ~180 jours. On le garde en mémoire pour ce process ;
// en prod, stocke-le plutôt dans une table (Postgres/Redis/Vercel KV)
// pour qu'il survive aux redéploiements, et rafraîchis-le avant expiration.

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now()) {
    return cachedToken.value;
  }

  const res = await fetch(`${CJ_BASE}/authentication/getAccessToken`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: process.env.CJ_EMAIL,
      password: process.env.CJ_API_KEY, // clé API générée dans ton compte CJ
    }),
  });

  const data = await res.json();
  if (!data.result) {
    throw new Error(`CJ auth failed: ${data.message}`);
  }

  cachedToken = {
    value: data.data.accessToken,
    // on se donne 1h de marge avant la vraie expiration (180 jours)
    expiresAt: new Date(data.data.accessTokenExpiryDate).getTime() - 60 * 60 * 1000,
  };

  return cachedToken.value;
}

async function cjFetch(path: string, options: RequestInit = {}) {
  const token = await getAccessToken();
  const res = await fetch(`${CJ_BASE}${path}`, {
    ...options,
    headers: {
      ...options.headers,
      "CJ-Access-Token": token,
      "Content-Type": "application/json",
    },
  });
  const data = await res.json();
  if (!data.result) {
    throw new Error(`CJ API error on ${path}: ${data.message}`);
  }
  return data.data;
}

// --- Produits par catégorie/niche -------------------------------------
export async function getProductsByCategory(
  categoryId: string,
  opts: { supplierId?: string; size?: number } = {}
): Promise<CjRawProduct[]> {
  const params = new URLSearchParams({
    categoryId,
    size: String(opts.size ?? 20),
    features: "enable_description",
  });
  if (opts.supplierId) params.set("supplierId", opts.supplierId);

  const data = await cjFetch(`/product/listV2?${params.toString()}`);
  // La réponse est groupée par "content[].productList[]"
  return data.content.flatMap((group: any) => group.productList);
}

// --- Détail produit (toutes les photos + variantes) --------------------
export async function getProductDetail(pid: string): Promise<CjRawProductDetail> {
  return cjFetch(`/product/query?pid=${pid}`);
}

// --- Avis clients --------------------------------------------------------
// NB: l'ancien endpoint /product/comments a été marqué comme déprécié par CJ.
// Vérifie dans ta console développeur CJ le nom exact de l'endpoint de
// remplacement ("Inquiry Reviews") avant mise en prod — l'appel ci-dessous
// fonctionne au moment de l'écriture mais peut changer de chemin.
export async function getProductReviews(pid: string): Promise<CjRawReview[]> {
  try {
    const data = await cjFetch(`/product/comments?pid=${pid}`);
    return data ?? [];
  } catch (err) {
    // Si l'endpoint a changé côté CJ, on ne casse pas toute la génération
    console.warn(`Impossible de récupérer les avis pour ${pid}:`, err);
    return [];
  }
}
