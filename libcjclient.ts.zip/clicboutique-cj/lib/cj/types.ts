// Types bruts renvoyés par l'API CJ Dropshipping (simplifiés aux champs qu'on utilise)

export interface CjRawProduct {
  id: string;
  nameEn: string;
  sku: string;
  bigImage: string;
  sellPrice: string;
  nowPrice: string;
  supplierName: string;
  supplierId: string;
  categoryId: string;
  description?: string;
  warehouseInventoryNum: number;
}

export interface CjRawProductDetail {
  pid: string;
  productNameEn: string;
  productSku: string;
  bigImage: string;
  productImageSet: string[];
  sellPrice: number;
  description: string;
  suggestSellPrice: string;
  supplierName: string;
  supplierId: string;
  variants: Array<{
    vid: string;
    variantNameEn: string;
    variantSku: string;
    variantImage: string;
    variantKey: string;
    variantSellPrice: number;
  }>;
}

export interface CjRawReview {
  id: string;
  content: string;
  score: number; // note sur 5
  images?: string[];
  createTime: string;
  countryCode?: string;
}

// Format final utilisé par ClicBoutique pour construire une fiche produit
export interface StoreProduct {
  cjProductId: string;
  title: string;
  description: string;
  images: string[]; // toutes les photos réelles CJ
  price: number;
  suggestedPrice?: string;
  variants: Array<{
    id: string;
    name: string;
    image: string;
    price: number;
  }>;
  reviews: Array<{
    author: string; // CJ ne fournit pas toujours de pseudo -> "Client vérifié"
    rating: number;
    text: string;
    images?: string[];
  }>;
  supplier: {
    id: string;
    name: string;
    contactUrl: string; // lien généré vers la page "contacter le fournisseur"
  };
}
