import { getProductDetail, getProductReviews } from "./client";
import type { StoreProduct } from "./types";

/**
 * Construit une fiche produit ClicBoutique 100% basée sur les vraies
 * données CJ : vraies photos, vrai prix, vrais avis, et un lien direct
 * vers la page de contact du fournisseur.
 */
export async function buildStoreProductFromCj(pid: string): Promise<StoreProduct> {
  const [detail, reviews] = await Promise.all([
    getProductDetail(pid),
    getProductReviews(pid),
  ]);

  return {
    cjProductId: detail.pid,
    title: detail.productNameEn,
    description: detail.description,
    images: detail.productImageSet?.length ? detail.productImageSet : [detail.bigImage],
    price: detail.sellPrice,
    suggestedPrice: detail.suggestSellPrice,
    variants: detail.variants.map((v) => ({
      id: v.vid,
      name: v.variantKey,
      image: v.variantImage || detail.bigImage,
      price: v.variantSellPrice,
    })),
    reviews: reviews.map((r) => ({
      author: "Client vérifié",
      rating: r.score,
      text: r.content,
      images: r.images,
    })),
    supplier: {
      id: detail.supplierId,
      name: detail.supplierName || "Fournisseur CJ",
      // Page interne de ClicBoutique où l'acheteur peut contacter le
      // fournisseur une fois la boutique exportée sur Shopify.
      contactUrl: `/fournisseur/${detail.supplierId}?produit=${detail.pid}`,
    },
  };
}

/**
 * Construit une boutique entière pour une niche donnée en récupérant
 * plusieurs produits du même fournisseur (pour rester cohérent, comme
 * demandé : mêmes fournisseur, mêmes photos, mêmes avis, même prix).
 */
export async function buildStoreCatalogForNiche(
  categoryId: string,
  supplierId: string,
  count = 12
): Promise<StoreProduct[]> {
  const { getProductsByCategory } = await import("./client");
  const products = await getProductsByCategory(categoryId, { supplierId, size: count });

  // On construit les fiches complètes en parallèle (photos + avis inclus)
  const fullProducts = await Promise.all(
    products.map((p) => buildStoreProductFromCj(p.id))
  );

  return fullProducts;
}
