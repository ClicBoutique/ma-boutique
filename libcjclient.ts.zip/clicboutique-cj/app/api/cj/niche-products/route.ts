import { buildStoreCatalogForNiche } from "@/lib/cj/mapper";

// Exemple d'appel côté front (dans ton générateur de boutique) :
// fetch(`/api/cj/niche-products?categoryId=${id}&supplierId=${sid}&count=12`)

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const categoryId = searchParams.get("categoryId");
  const supplierId = searchParams.get("supplierId");
  const count = Number(searchParams.get("count") ?? 12);

  if (!categoryId || !supplierId) {
    return Response.json(
      { error: "categoryId et supplierId sont requis" },
      { status: 400 }
    );
  }

  try {
    const products = await buildStoreCatalogForNiche(categoryId, supplierId, count);
    return Response.json({ products });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Échec de la récupération CJ" }, { status: 500 });
  }
}
