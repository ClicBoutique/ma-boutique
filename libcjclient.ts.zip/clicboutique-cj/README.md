# Intégration CJ Dropshipping → ClicBoutique

Ces fichiers ajoutent une vraie source de données produits (photos, avis,
prix, fournisseur) venant de CJ Dropshipping, à la place des données
générées par l'IA.

## 1. Où mettre ces fichiers dans ton repo GitHub

Copie les dossiers tels quels à la racine de ton projet Next.js :

```
ton-repo/
├── app/
│   └── api/
│       └── cj/
│           └── niche-products/
│               └── route.ts       ← nouveau
├── lib/
│   └── cj/
│       ├── client.ts               ← nouveau
│       ├── mapper.ts                ← nouveau
│       └── types.ts                 ← nouveau
└── .env.example                     ← à fusionner avec le tien
```

Si ton projet n'utilise pas l'alias `@/lib/...`, adapte l'import dans
`app/api/cj/niche-products/route.ts` avec le chemin relatif correct
(ex: `../../../../lib/cj/mapper`).

## 2. Créer un compte développeur CJ

1. Crée un compte sur https://cjdropshipping.com puis active l'accès API
   sur https://developers.cjdropshipping.com
2. Récupère ton email de connexion et ta clé API (`CJ_API_KEY`).
3. Sur Vercel : Project Settings → Environment Variables, ajoute
   `CJ_EMAIL` et `CJ_API_KEY` (reprends `.env.example`).

## 3. Trouver les `categoryId` et `supplierId` de tes niches

- `categoryId` : appelle `GET /product/getCategory` (voir `client.ts`,
  fonction à ajouter si besoin) pour lister les catégories CJ et repérer
  celle qui correspond à chaque niche de ta boutique (Bijoux artisanaux,
  Fitness & compléments, etc.).
- `supplierId` : une fois un `categoryId` choisi, appelle
  `getProductsByCategory(categoryId)` sans filtre `supplierId`, regarde
  les résultats et repère le `supplierId` d'un fournisseur qui a
  plusieurs bons articles cohérents dans cette niche. Fige-le ensuite
  dans ta config (un `supplierId` par niche).

## 4. Brancher ça dans ton générateur de boutique

Au moment où l'IA génère la boutique pour une niche choisie, remplace
l'étape "génération des produits" par un appel à :

```ts
const res = await fetch(
  `/api/cj/niche-products?categoryId=${categoryId}&supplierId=${supplierId}&count=12`
);
const { products } = await res.json();
```

Chaque `product` contient déjà :
- `images` : les vraies photos CJ (pas juste la principale)
- `price` / `suggestedPrice`
- `reviews` : les vrais avis clients CJ
- `supplier.contactUrl` : le lien à afficher sur la page "contacter le
  fournisseur" après export Shopify

## 5. À vérifier avant la mise en prod

- L'endpoint des avis (`/product/comments`) est marqué comme
  **déprécié** par CJ. Vérifie dans leur doc à jour
  (developers.cjdropshipping.com → Product → 4 Product Reviews) le nom
  exact de l'endpoint de remplacement et mets à jour `client.ts` si besoin.
- Le token CJ dure ~180 jours : en prod, stocke-le dans une base plutôt
  qu'en mémoire (le cache mémoire actuel repart de zéro à chaque
  redéploiement Vercel, ce qui redemande un login à chaque déploiement —
  sans problème en soi, juste à savoir).
- Limite CJ : ~1000 requêtes/jour pour un compte gratuit/v1 — pense à
  mettre en cache les catalogues générés plutôt que d'appeler CJ à
  chaque visite.
